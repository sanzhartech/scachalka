﻿<div align="center">

<img src="assets/logo.png" width="140" alt="Scachalka logo" />

# Scachalka

**Скачивай легко** — a fast, native Windows GUI that puts the full power of **yt-dlp** and **FFmpeg** behind a modern interface. Paste links, drop a whole Apple Music library or a 10 000-row CSV — Scachalka handles the rest.

[![CI](https://github.com/sanzhartech/scachalka/actions/workflows/ci.yml/badge.svg)](../../actions/workflows/ci.yml)
![.NET 8](https://img.shields.io/badge/.NET-8.0-blueviolet)
![Platform](https://img.shields.io/badge/Windows-10%2F11-0078D6)
![License](https://img.shields.io/badge/license-MIT-green)

[Русская версия](README.md) · English

</div>

---

Scachalka never reimplements downloader logic — it orchestrates your locally installed
yt-dlp and FFmpeg through process execution, with a clean, crash-resistant UI.

## Features

### Downloading
- Paste one or many URLs (space/newline separated), drag & drop, `Ctrl+Shift+V` paste-and-add
- URL validation up front — garbage never reaches the process layer
- **Playlists**: one toggle downloads whole playlists into `<playlist>/NN - title` subfolders
- Download queue with bounded parallelism (2 by default)
- Per-item progress bar, speed, ETA, size and stage (metadata → downloading → merging → converting)
- Cancel (kills the whole yt-dlp/ffmpeg process tree, cleans up `*.part` files) and retry

### 🎵 Import Apple Music Library

Export your library from the Apple Music app as plain text (`songs.txt`), click
**Import Apple Music Library** — and every song is found and downloaded fully automatically.
No manual searching, no pasting URLs.

- Parses Apple Music / iTunes plain-text exports (tab-separated, UTF-16/UTF-8, EN + RU
  headers) and simple `Artist - Title` lists
- Searches **both YouTube and YouTube Music** (`ytsearch10:` + music.youtube.com) through
  yt-dlp — metadata only, no wasted downloads
- **Intelligent matching** with a 0–100 confidence score: title similarity, artist evidence
  (official artist channel, `- Topic` auto-channels), track duration proximity, and
  official-source signals (Official Audio / Official Music Video / VEVO / verified channel)
- **Never downloads altered versions**: nightcore, slowed + reverb, sped up, bass boosted,
  remix, mashup, cover, karaoke, instrumental, live, AI versions and lyric videos are
  heavily penalized — accuracy over speed
- Skipped songs go to `failed_songs.txt` with the reason (`No match found` /
  `Confidence too low`); the run never stops on a single failure
- Live progress (`Searching 12 / 508`, `Matched: Official Audio · Confidence: 98%`) and a
  final summary with totals and elapsed time
- Scales to libraries with thousands of songs — searching and downloading run in parallel

### 📄 Bulk Import Links

Import hundreds or thousands of YouTube / YouTube Music links from a file — every valid
link goes straight into the existing download queue.

- **CSV** — URL column found by header (`youtube_music_url` / `youtube_url` / `url` /
  `link`), other columns ignored; quoted fields and `,` / `;` / tab delimiters handled
- **JSON** — arrays of URL strings, arrays of objects (same keys, case-insensitive), or a
  root object with arrays
- **TXT** — one URL per line
- Format detected automatically; the importer is pluggable, so new formats (M3U, Spotify
  exports, …) are one class away
- Validation against supported domains (`youtube.com`, `music.youtube.com`, `youtu.be`,
  `m.youtube.com`) with per-link reasons
- **Smart duplicate detection** — the same video via `youtu.be/…`, `watch?v=…` and
  YouTube Music counts as one; import order is preserved
- Rejected links saved to `failed_links.txt` (`Invalid URL` / `Unsupported domain` /
  `Missing URL` / `Duplicate`); summary shows imported / queued / duplicates / invalid
- Built for 10 000+ links: reading, parsing and validation run off the UI thread

### Formats
- Video: **MP4**, **MKV** with quality cap: Best / 4K / 1440p / 1080p / 720p / 480p / 360p
- Audio: **MP3, M4A, OPUS, FLAC, WAV** — best source audio, converted by FFmpeg

### Full yt-dlp power (Advanced panel)
- **Subtitles with UTF-8 BOM**: embeds subtitles into video containers and keeps clean .srt files alongside the video. Defaults to **Russian, English, and Kazakh** (u,en,kk) with auto-generated subtitles fallback (--write-auto-subs). Scachalka automatically ensures all .srt files are written with **UTF-8 BOM (EF BB BF)**, preventing Cyrillic/Kazakh mojibake in Windows Media Player and smart TVs.
- **Embed metadata & chapters, thumbnail (cover art)**.
- **Cookies from your browser** (Chrome/Edge/Firefox/Brave/Opera/Vivaldi) for private,
  age-restricted or member-only videos — and if the browser is open and locks its cookie
  database, Scachalka automatically retries the download without cookies instead of failing.
- **Extra yt-dlp arguments** field — anything yt-dlp can do (--limit-rate, --proxy,
  --live-from-start, SponsorBlock, --cookies, …); appended last, so it overrides any default.

### 🍪 YouTube Cookies (Recommended for YouTube)

Due to YouTube's strict anti-bot protections (*"Sign in to confirm you're not a bot"*, HTTP 429, or silent download blocks), providing cookies is now often required for reliable downloading from YouTube:

1. **Method 1 (Direct from Browser):** In **Advanced options**, select your browser (e.g. chrome, irefox, edge) in the **Cookies from browser** dropdown.
2. **Method 2 (Cookies text file via Custom Arguments):** Export your YouTube cookies from your browser (e.g. using the *"Get cookies.txt LOCALLY"* browser extension) to a .txt file, and specify the path in **Extra arguments**:
   `
   --cookies "C:\Users\syste\Desktop\Scachalka-source\www.youtube.com_cookies.txt"
   `
   *(Adjust the path to match the location of your cookies.txt file).*

### Comfort
- **Bilingual UI (English / Русский)** with instant runtime switch, auto-detected from the OS
- Dark and light theme (dark by default, runtime switch, dark title bar on Win11)
- Log window + session log files in `%APPDATA%\Scachalka\logs`
- Open destination folder / reveal downloaded file in Explorer
- Unicode-safe file names; friendly localized error messages
- Settings persisted as JSON (folder, format, quality, theme, language, all advanced options)

## Requirements

| Requirement | Notes |
|---|---|
| Windows 10/11 x64 | |
| [yt-dlp](https://github.com/yt-dlp/yt-dlp) | `winget install yt-dlp.yt-dlp` |
| [FFmpeg](https://ffmpeg.org) | `winget install Gyan.FFmpeg` (or bundled with the yt-dlp winget package) |
| .NET 8 SDK | **Build only** — the published exe is self-contained |

Scachalka finds the tools automatically: next to `Scachalka.exe` → `tools\` subfolder →
every `PATH` entry → WinGet links. If they are missing, a banner explains what to install;
press **Re-check tools** afterwards.

## Download & run (users)

1. Grab `Scachalka.exe` from the [latest release](../../releases/latest).
2. Install yt-dlp and FFmpeg (see Requirements).
3. Run `Scachalka.exe` — no installer, no admin rights. Settings live in `%APPDATA%\Scachalka\`.

### Importing an Apple Music library

1. In the Apple Music app (or iTunes): select your songs / playlist →
   **File → Library → Export Playlist…** → save as plain text (`songs.txt`).
2. In Scachalka: pick an audio format (MP3 by default), click **Import Apple Music Library**
   and choose the file.
3. Watch the progress. Anything that could not be matched confidently lands in
   `failed_songs.txt` next to your downloads.

### Bulk importing links

Prepare a CSV, TXT or JSON file with links (see Features for the recognized shapes),
click **Bulk Import Links**, choose the file — every valid, non-duplicate link is queued
and downloaded automatically. Rejected links land in `failed_links.txt` with reasons.

## Build from source (developers)

```powershell
git clone https://github.com/sanzhartech/scachalka.git
cd scachalka
dotnet publish -c Release -r win-x64 --self-contained true
```

Portable single-file executable:

```
src\YtDlpGui.App\bin\Release\net8.0-windows\win-x64\publish\Scachalka.exe
```

Run tests:

```powershell
dotnet test
```

## Releases (maintainers)

Tag a version and CI builds and publishes the portable exe automatically:

```bash
git tag v1.2.0
git push origin v1.2.0
```

The [release workflow](.github/workflows/release.yml) runs tests, publishes the
self-contained exe, and attaches `Scachalka.exe` + a zip to a GitHub Release.

## Logo / icon

The app icon lives at `assets/scachalka.ico` and is generated from `assets/logo.png` by
[`tools/generate-icon.ps1`](tools/generate-icon.ps1). To use your own artwork, replace
`assets/logo.png` with a square PNG and re-run:

```powershell
pwsh tools/generate-icon.ps1
```

Both the executable icon and the window icon pick it up on the next build.

## Architecture

Clean layered architecture with strictly one-directional dependencies:

```
YtDlpGui.App            composition root: DI wiring, app lifecycle
  ├─ YtDlpGui.UI            WPF views, view models (MVVM), themes, localization, converters
  │    └─ YtDlpGui.Application   queue coordinator, download executor, job model,
  │         │                    library import + bulk import orchestration
  │         └─ YtDlpGui.Core          URL validation, argument-builder strategies,
  │              │                    progress parser, error classifier, retry policy,
  │              │                    Apple Music parser, song match scorer,
  │              │                    link sources (CSV/JSON/TXT) + bulk link analyzer
  │              └─ YtDlpGui.Abstractions   interfaces, models, localization contract
  └─ YtDlpGui.Infrastructure  process runner (kill-tree), tool locator,
                              JSON settings, logging, string catalogs
```

- **Strategy pattern for formats** (`IArgumentBuilder`) — new formats add a class, not edits.
- **Strategy pattern for import formats** (`ILinkSource`) — CSV/JSON/TXT today; M3U or
  Spotify exports later without touching the import engine.
- **Pure matching logic** (`ISongMatchScorer`) — the Apple Music matcher is deterministic,
  I/O-free and covered by unit tests.
- **Machine-readable progress** via `--progress-template` with a resilient fallback parser.
- **Injection-proof process execution**: `ArgumentList` + `--` terminator, no shell.
- **Cancellation kills the entire process tree** and removes `*.part` leftovers.
- **UI never blocks**: async IO, throttled progress, collections mutated only on the UI thread.

See [CONTRIBUTING.md](CONTRIBUTING.md) for the full module guide.

## Documentation
- 📐 [Detailed Architecture Guide](docs/ARCHITECTURE.md) — deep dive into layers, patterns, and sequences.
- 📖 [User Guide](docs/USER_GUIDE.md) — complete user manual with installation and usage instructions.
- 🎓 [Project Defense Material](docs/DEFENSE_PRESENTATION.md) — academic presentation outline, talking points, and Q&A.

## Legal

Scachalka is a general-purpose GUI wrapper for yt-dlp. Use it only for content you are
allowed to download. It intentionally does **not** include features whose sole purpose is
to bypass site access controls (anti-bot, DRM) or to enable copyright infringement.

## License

[MIT](LICENSE)
